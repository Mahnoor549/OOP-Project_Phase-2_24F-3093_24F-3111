#include "Leader.h"
#include "Military.h"
#include "Economy.h"

Leader::Leader(string leaderName, string leaderTitle, bool democratic)
    : name(leaderName), title(leaderTitle), isDemocratic(democratic),
    approvalRating(70), termYears(0) {
}


void Leader::holdElection(Economy& economy) {
    if (!isDemocratic) {
        cout << "No elections in a dictatorship!" << endl;
        return;
    }

    economy.allocateBudget(500, 0);  
    approvalRating = 50 + rand() % 50;
    termYears = 0;
    cout << name << " won the election! Approval: " << approvalRating << "%" << endl;
}

void Leader::handleCoup(Military& military) {
    if (military.getMorale() < 30) {
        cout << "COUP! " << name << " was overthrown by the army!" << endl;
        name = "Military Junta";
        title = "General";
        approvalRating = 40;
    }
    else {
        cout << "The army remains loyal to " << name << endl;
    }
}


void Leader::declareWar(Military& military, Economy& economy) {
    if (economy.getTreasury() < 1000) {
        cout << "Not enough gold for war!" << endl;
        return;
    }

    economy.allocateBudget(800, 0);  
    military.trainArmy(5);         
    approvalRating += 10;

    cout << name << " declares WAR! Army mobilized." << endl;
}


void Leader::makePeace() {
    approvalRating -= 20;
    cout << name << " negotiated peace. Citizens are unhappy (-20 approval)." << endl;
}

void Leader::corruptTreasury(Economy& economy) {
    int stolenAmount = 200;
    economy.allocateBudget(-stolenAmount, 0); 
    cout << name << " stole " << stolenAmount << " gold from treasury!" << endl;
}


string Leader::getName() { return name; }
string Leader::getTitle() { return title; }
int Leader::getApproval() { return approvalRating; }