#pragma once
#include "social.h"  
using namespace std;

class Economy {
private:
    int treasury;        
    float inflation;   
    int militaryBudget;  
    int foodBudget;      

public:
    Economy(); 
    void collectTaxes(SocialClass* classes[], int classCount);
    void adjustInflation(int totalSpending);
    void allocateBudget(int military, int food);
    int getTreasury();
    float getInflation();
};
