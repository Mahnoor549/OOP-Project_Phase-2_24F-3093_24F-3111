#include "Conflict.h"
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
using namespace std;

// Battle implementation
Battle::Battle(string loc, int attStr, int defStr, float terrainMod) :
    location(loc), attackerStrength(attStr), defenderStrength(defStr),
    terrainModifier(terrainMod) {
}

void Battle::simulate() {
    cout << "\n=== BATTLE AT " << location << " ===" << endl;
    cout << "Attacker strength: " << attackerStrength << endl;
    cout << "Defender strength: " << defenderStrength << endl;

    // Apply terrain modifier (0.8-1.2 range)
    float defFinal = defenderStrength * terrainModifier;
    float attFinal = attackerStrength * (2.0 - terrainModifier); // Inverse effect

    cout << "After terrain modifiers:" << endl;
    cout << "Attacker effective: " << attFinal << endl;
    cout << "Defender effective: " << defFinal << endl;

    // Simple battle outcome
    if (attFinal > defFinal * 1.2) {
        cout << "DECISIVE ATTACKER VICTORY!" << endl;
    }
    else if (attFinal > defFinal) {
        cout << "Attacker wins with heavy losses" << endl;
    }
    else if (defFinal > attFinal * 1.2) {
        cout << "CRUSHING DEFENDER VICTORY!" << endl;
    }
    else {
        cout << "Defender repels the attack" << endl;
    }
}

// War implementation
War::War(string agg, string def, string goal) :
    aggressor(agg), defender(def), warGoal(goal), isActive(true) {
    warDuration = 0;
}

void War::declare() {
    cout << "\n" << aggressor << " has declared war on " << defender << "!" << endl;
    cout << "Casus Belli: " << warGoal << endl;
}

void War::proposePeace() {
    isActive = false;
    cout << "\nPEACE TREATY signed between " << aggressor << " and " << defender << endl;
}

void War::calculateOutcome() {
    // Simple war outcome based on duration
    if (warDuration < 7) {
        cout << "White peace - no territory changes" << endl;
    }
    else if (warDuration < 30) {
        cout << aggressor << " gains minor concessions" << endl;
    }
    else {
        cout << defender << " collapses from war exhaustion!" << endl;
    }
}

void War::saveToFile() const {
    ofstream file("wars.txt", ios::app);
    if (file.is_open()) {
        file << aggressor << "," << defender << "," << warGoal << ","
            << (isActive ? "Active" : "Ended") << endl;
        file.close();
    }
}

// Betrayal implementation
Betrayal::Betrayal(string betr, string vict, string meth, int sev) :
    betrayer(betr), victim(vict), method(meth), severity(sev) {
}

void Betrayal::applyConsequences() {
    cout << "\n=== BETRAYAL ===" << endl;
    cout << betrayer << " has betrayed " << victim << "!" << endl;
    cout << "Method: " << method << endl;

    if (severity > 7) {
        cout << "MAJOR betrayal! " << betrayer << "'s reputation is ruined!" << endl;
    }
    else if (severity > 3) {
        cout << "Significant reputation damage to " << betrayer << endl;
    }
    else {
        cout << "Minor diplomatic incident" << endl;
    }
}

void Betrayal::saveToFile() const {
    ofstream file("betrayals.txt", ios::app);
    if (file.is_open()) {
        file << betrayer << "," << victim << "," << method << "," << severity << endl;
        file.close();
    }
}

// ConflictManager implementation
ConflictManager::ConflictManager() : warCount(0) {
    srand(time(0));
}

void ConflictManager::startWar() {
    if (warCount >= MAX_WARS) {
        cout << "Maximum concurrent wars reached!" << endl;
        return;
    }

    string agg, def, goal;
    cout << "\nEnter aggressor kingdom: ";
    getline(cin, agg);
    cout << "Enter defender kingdom: ";
    getline(cin, def);
    cout << "Enter war goal: ";
    getline(cin, goal);

    activeWars[warCount] = new War(agg, def, goal);
    activeWars[warCount]->declare();
    activeWars[warCount]->saveToFile();
    warCount++;

    // Simulate first battle
    int attStr = 5000 + rand() % 5000;
    int defStr = 5000 + rand() % 5000;
    float terrainMod = 0.8 + (rand() % 5) * 0.1; // 0.8-1.2
    Battle firstBattle("Borderlands", attStr, defStr, terrainMod);
    firstBattle.simulate();
}

void ConflictManager::listActiveWars() const {
    cout << "\n=== ACTIVE WARS ===" << endl;
    for (int i = 0; i < warCount; i++) {
        if (activeWars[i]->isActive) {
            cout << i + 1 << ". " << activeWars[i]->aggressor << " vs "
                << activeWars[i]->defender << " - " << activeWars[i]->warGoal << endl;
        }
    }
}

void ConflictManager::resolveWar() {
    listActiveWars();
    if (warCount == 0) return;

    int choice;
    cout << "Enter war number to resolve (0 to cancel): ";
    cin >> choice;
    cin.ignore();

    if (choice > 0 && choice <= warCount) {
        activeWars[choice - 1]->proposePeace();
        activeWars[choice - 1]->calculateOutcome();
        activeWars[choice - 1]->saveToFile();
    }
}

void ConflictManager::commitBetrayal() {
    string betr, vict, method;
    int severity;

    cout << "\nEnter betrayer kingdom: ";
    getline(cin, betr);
    cout << "Enter victim kingdom: ";
    getline(cin, vict);
    cout << "Enter betrayal method: ";
    getline(cin, method);
    cout << "Enter severity (1-10): ";
    cin >> severity;
    cin.ignore();

    Betrayal betrayal(betr, vict, method, severity);
    betrayal.applyConsequences();
    betrayal.saveToFile();
}