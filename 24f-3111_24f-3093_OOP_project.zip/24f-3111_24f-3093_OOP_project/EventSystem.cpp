#include "EventSystem.h"
#include "Population.h"
#include "Economy.h"
#include "Military.h"

EventSystem::EventSystem() {
    srand(time(0));  
    eventSeverity = 5; 
}


void EventSystem::triggerEvent(Population& pop, Economy& economy, Military& military) {
    int eventType = rand() % 3;  // 0=Famine, 1=Plague, 2=War

    cout << "\n=== EVENT TRIGGERED ===" << endl;
    switch (eventType) {
    case 0:
        applyFamine(pop);
        break;
    case 1:
        applyPlague(pop);
        break;
    case 2:
        applyWar(economy, military);
        break;
    }
}

void EventSystem::resolveEvent(int choice, Population& pop, Economy& economy) {
    cout << "Resolving event..." << endl;
    switch (choice) {
    case 1:  
        economy.allocateBudget(-500, 0);
        pop.updatePopulation(50);  
        cout << "Spent 500 gold to mitigate effects" << endl;
        break;
    case 2:  
        cout << "No action taken - consequences worsen" << endl;
        eventSeverity += 2;
        break;
    }
}


void EventSystem::applyFamine(Population& pop) {
    cout << "FAMINE! Crops have failed" << endl;
    pop.updatePopulation(-100);  
    pop.calculateHappiness(-20);
}

void EventSystem::applyPlague(Population& pop) {
    cout << "PLAGUE! Disease spreads" << endl;
    pop.updatePopulation(-150);
}

void EventSystem::applyWar(Economy& economy, Military& military) {
    cout << "WAR DECLARED!" << endl;
    economy.allocateBudget(1000, 0);  // War costs
    military.trainArmy(3);            // Emergency training
}