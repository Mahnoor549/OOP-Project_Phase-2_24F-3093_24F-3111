#pragma once
#ifndef CONFLICT_H
#define CONFLICT_H

#include <string>
using namespace std;
class ConflictManager;
class Battle {
private:
    string location;
    int attackerStrength;
    int defenderStrength;
    float terrainModifier;
public:
    Battle(string loc, int attStr, int defStr, float terrainMod);
    void simulate();
};

class War {
private:
    string aggressor;
    string defender;
    string warGoal;
    int warDuration; // days
    bool isActive;
    friend class ConflictManager;
public:
    War(string agg, string def, string goal);
    void declare();
    void proposePeace();
    void calculateOutcome();
    void saveToFile() const;
};

class Betrayal {
private:
    string betrayer;
    string victim;
    string method;
    int severity;
public:
    Betrayal(string betr, string vict, string meth, int sev);
    void applyConsequences();
    void saveToFile() const;
};

class ConflictManager {
private:
    static const int MAX_WARS = 10;
    War* activeWars[MAX_WARS];
    int warCount;
public:
    ConflictManager();
    void startWar();
    void listActiveWars() const;
    void resolveWar();
    void commitBetrayal();
   
};

#endif
