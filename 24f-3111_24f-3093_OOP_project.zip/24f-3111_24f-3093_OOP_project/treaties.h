#pragma once
#ifndef TREATY_H
#define TREATY_H

#include <string>
#include <ctime>
using namespace std;

class Treaty {
protected:
    string kingdom1;
    string kingdom2;
    time_t startDate;
    int duration; // in days
    bool active;
public:
    Treaty(string k1, string k2, int dur);
    virtual ~Treaty() {}
    virtual string getTerms() const = 0; // pure virtual
    bool isActive() const;
    void breakTreaty();
    virtual void display() const;
    void saveToFile() const;
};

class AllianceTreaty : public Treaty {
public:
    AllianceTreaty(string k1, string k2, int dur);
    string getTerms() const override;
};

class TradeTreaty : public Treaty {
    int tradeBonus; // percentage
public:
    TradeTreaty(string k1, string k2, int dur, int bonus);
    string getTerms() const override;
};

class DiplomacyManager {
    static const int MAX_TREATIES = 50;
    Treaty* treaties[MAX_TREATIES];
    int treatyCount;
public:
    DiplomacyManager();
    void proposeTreaty();
    void listActiveTreaties() const;
    void breakTreaty();
};

#endif
