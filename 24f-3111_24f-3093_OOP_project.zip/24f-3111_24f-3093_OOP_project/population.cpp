#include "Population.h"

Population::Population() {
    totalPeople = 1000;
    happiness = 70;
    foodSupply = 500;
}

void Population::updatePopulation(int h) {
    if (foodSupply >= totalPeople) {
        totalPeople += totalPeople * 0.05; 
        happiness += h;
    }
    else {
        totalPeople -= totalPeople * 0.10; 
        happiness -= 15;
    }
    if (totalPeople < 0) totalPeople = 0;
}

void Population::calculateHappiness(int h) {
    if (foodSupply < totalPeople / 2) {
        happiness -= h;
    }
    happiness = max(0, min(100, happiness));
}

bool Population::triggerRevolt() {
    if (happiness < 30) {
        cout << "REVOLT! The people are angry!" << endl;
        return true;
    }
    return false;
}

int Population::getPopulation() { return totalPeople; }
int Population::getHappiness() { return happiness; }

void Population::setFoodSupply(int food) { foodSupply = food; }