#pragma once
#include "Population.h"
#include "Military.h"
#include "Economy.h"
#include "Bank.h"
#include "Leader.h"
#include "EventSystem.h"
#include "ResourceManagement.h"
#include "Peasant.h"
#include "Merchant.h"
#include "Noble.h"
using namespace std;
class Kingdom {
private:
    int gold;       
    int food;       
    int populations; 
    bool isGameOver;
    Population population;
    Military military;
    Economy economy;
    Bank bank;
    Leader leader;
    EventSystem events;
    ResourceManager resources;
    int dayCount;
    void showMenu();
    void handleChoice(int choice);
    void updateGameState();
    void displayStatus();

public:
    Kingdom();      
    void runSimulation(); 
    void handleRandomEvents();
    bool checkGameOver(); 
};