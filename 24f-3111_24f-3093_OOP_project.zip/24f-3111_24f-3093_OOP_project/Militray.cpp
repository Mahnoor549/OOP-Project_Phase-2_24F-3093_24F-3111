#include "Military.h"
#include "Population.h"  // For population integration

Military::Military()
    : soldierCount(100), armyStrength(50), morale(70),
    trainingLevel(5), weapons(200) {
}

// Recruits soldiers from population (reduces population)
void Military::recruitSoldiers(Population& population, int recruits) {
    int availablePeople = population.getPopulation() / 10;  // 10% max can join

    if (recruits > availablePeople) {
        cout << "Not enough people to recruit!" << endl;
        recruits = availablePeople;
    }

    soldierCount += recruits;
    population.updatePopulation(10); 
    cout << "Recruited " << recruits << " soldiers. Total army: "
        << soldierCount << endl;
}


void Military::trainArmy(int days) {
    armyStrength += days * trainingLevel;
    if (armyStrength > 100) armyStrength = 100;

    cout << "Army trained for " << days << " days. Strength: "
        << armyStrength << "/100" << endl;
}

void Military::checkMorale(int foodSupply, int goldPayment) {
    if (foodSupply < soldierCount || goldPayment < 10) {
        morale -= 20;
        cout << "Low supplies! Morale drops." << endl;
    }
    else {
        morale += 10;
    }
    morale = max(1, min(100, morale)); 
}


bool Military::fightBattle(int enemyStrength) {
    int power = armyStrength * soldierCount / 100;

    if (power > enemyStrength) {
        cout << "Battle WON! Army gains experience." << endl;
        trainingLevel++;
        return true;
    }
    else {
        cout << "Battle LOST! Soldiers died." << endl;
        soldierCount *= 0.8;
        return false;
    }
}

int Military::getSoldierCount() { return soldierCount; }
int Military::getArmyStrength() { return armyStrength; }
int Military::getMorale() { return morale; }

void Military::setWeapons(int count) { weapons = count; }