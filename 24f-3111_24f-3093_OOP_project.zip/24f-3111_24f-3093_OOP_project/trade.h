#pragma once
#ifndef TRADE_H
#define TRADE_H

#include <string>
using namespace std;

class TradeOffer {
private:
    string offeringKingdom;
    string requestedResource;
    string offeredResource;
    int requestedAmount;
    int offeredAmount;
    bool isLegal;
    float riskPercentage;
public:
    TradeOffer(string kingdom, string reqRes, string offRes,
        int reqAmt, int offAmt, bool legal);
    void display() const;
    bool executeTrade();
    float calculateRisk() const;
    void saveToFile() const;
};

class Market {
private:
    static const int MAX_OFFERS = 50;
    TradeOffer* legalOffers[MAX_OFFERS];
    TradeOffer* blackMarketOffers[MAX_OFFERS];
    int legalCount;
    int blackMarketCount;
    float priceIndex;
public:
    Market();
    void postOffer();
    void listOffers(bool showLegal) const;
    void acceptOffer(bool isLegal);
    void adjustPrices();
    bool detectSmuggling() const;
};

#endif
