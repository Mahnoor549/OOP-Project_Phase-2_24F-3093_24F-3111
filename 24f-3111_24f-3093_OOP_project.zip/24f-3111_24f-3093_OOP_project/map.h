#pragma once
#ifndef MAP_H
#define MAP_H

#include <string>
using namespace std;

class Territory {
private:
    string name;
    string owner;
    int resources;
    int defenses;
public:
    Territory(string n, string o, int res, int def);
    void display() const;
    void changeOwner(string newOwner);
    void upgradeDefenses();
    string getName() const;
    string getOwner() const;
};

class Movement {
private:
    string movingEntity;
   
    int progress; // percentage
public:
    string startTerritory;
    string endTerritory;
    Movement(string entity, string start, string end);
    void updatePosition();
    bool isComplete() const;
    void display() const;
};

class GameMap {
private:
    static const int SIZE = 5;
    Territory* territories[SIZE][SIZE];
    Movement* movements[10];
    int movementCount;
public:
    GameMap();
    void initializeMap();
    void display() const;
    void moveArmy();
    void updateMovements();
    int calculateDistance(string t1, string t2) const;
    Territory* findTerritory(string name) const;
};
#endif
