#include "Kingdom.h"
#include "Message.h"
#include "Trade.h"
#include "Treaties.h"
#include "Conflict.h"
#include "Map.h"
#include <iostream>
using namespace std;

void displayMainMenu() {
    cout << "\n=== STRONGHOLD KINGDOM SIMULATOR ===" << endl;
    cout << "1. Communication System" << endl;
    cout << "2. Trade and Market System" << endl;
    cout << "3. Treaties and Diplomacy" << endl;
    cout << "4. Conflict and War System" << endl;
    cout << "5. Map and Movement System" << endl;
    cout << "6. Exit" << endl;
    cout << "Choose a system (1-6): ";
}

void communicationMenu(CommunicationCenter& comm) {
    int choice;
    do {
        cout << "\n=== COMMUNICATION SYSTEM ===" << endl;
        cout << "1. Send Message" << endl;
        cout << "2. View Message History" << endl;
        cout << "3. Back to Main Menu" << endl;
        cout << "Choose: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: comm.sendMessage(); break;
        case 2: comm.viewMessageHistory(); break;
        case 3: break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 3);
}

void tradeMenu(Market& market) {
    int choice;
    do {
        cout << "\n=== TRADE SYSTEM ===" << endl;
        cout << "1. Post Trade Offer" << endl;
        cout << "2. View Legal Offers" << endl;
        cout << "3. View Black Market Offers" << endl;
        cout << "4. Accept Legal Offer" << endl;
        cout << "5. Accept Black Market Offer" << endl;
        cout << "6. Check Market Status" << endl;
        cout << "7. Back to Main Menu" << endl;
        cout << "Choose: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: market.postOffer(); break;
        case 2: market.listOffers(true); break;
        case 3: market.listOffers(false); break;
        case 4: market.acceptOffer(true); break;
        case 5: market.acceptOffer(false); break;
        case 6:
            if (market.detectSmuggling()) {
                cout << "Authorities are cracking down on smuggling today!" << endl;
            }
            else {
                cout << "Market operating normally today." << endl;
            }
            break;
        case 7: break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 7);
}

void diplomacyMenu(DiplomacyManager& diplomacy) {
    int choice;
    do {
        cout << "\n=== DIPLOMACY SYSTEM ===" << endl;
        cout << "1. Propose New Treaty" << endl;
        cout << "2. List Active Treaties" << endl;
        cout << "3. Break a Treaty" << endl;
        cout << "4. Back to Main Menu" << endl;
        cout << "Choose: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: diplomacy.proposeTreaty(); break;
        case 2: diplomacy.listActiveTreaties(); break;
        case 3: diplomacy.breakTreaty(); break;
        case 4: break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 4);
}

void conflictMenu(ConflictManager& conflict) {
    int choice;
    do {
        cout << "\n=== CONFLICT SYSTEM ===" << endl;
        cout << "1. Declare War" << endl;
        cout << "2. List Active Wars" << endl;
        cout << "3. Resolve War" << endl;
        cout << "4. Commit Betrayal" << endl;
        cout << "5. Back to Main Menu" << endl;
        cout << "Choose: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: conflict.startWar(); break;
        case 2: conflict.listActiveWars(); break;
        case 3: conflict.resolveWar(); break;
        case 4: conflict.commitBetrayal(); break;
        case 5: break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 5);
}

void mapMenu(GameMap& worldMap) {
    int choice;
    do {
        cout << "\n=== MAP SYSTEM ===" << endl;
        cout << "1. Display Map" << endl;
        cout << "2. Move Army" << endl;
        cout << "3. Update Movements" << endl;
        cout << "4. Calculate Distance" << endl;
        cout << "5. Back to Main Menu" << endl;
        cout << "Choose: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: worldMap.display(); break;
        case 2: worldMap.moveArmy(); break;
        case 3: worldMap.updateMovements(); break;
        case 4: {
            string t1, t2;
            cout << "Enter first territory: ";
            getline(cin, t1);
            cout << "Enter second territory: ";
            getline(cin, t2);
            int dist = worldMap.calculateDistance(t1, t2);
            if (dist >= 0) {
                cout << "Distance: " << dist << " territories" << endl;
            }
            else {
                cout << "Invalid territory names!" << endl;
            }
            break;
        }
        case 5: break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (choice != 5);
}

int main() {
    // Initialize all systems
    CommunicationCenter commCenter;
    Market market;
    DiplomacyManager diplomacy;
    ConflictManager conflict;
    GameMap worldMap;

    int mainChoice;
    Kingdom myKingdom;

    cout << "Welcome to StrongHold Kingdom Simulator!" << endl;
    cout << "Starting new game..." << endl;

    myKingdom.runSimulation();  // Starts the game loop

    do {
        displayMainMenu();
        cin >> mainChoice;
        cin.ignore();

        switch (mainChoice) {
        case 1: communicationMenu(commCenter); break;
        case 2: tradeMenu(market); break;
        case 3: diplomacyMenu(diplomacy); break;
        case 4: conflictMenu(conflict); break;
        case 5: mapMenu(worldMap); break;
        case 6: cout << "Exiting Stronghold Kingdom Simulator..." << endl; break;
        default: cout << "Invalid choice!" << endl;
        }
    } while (mainChoice != 6);

    return 0;
}
