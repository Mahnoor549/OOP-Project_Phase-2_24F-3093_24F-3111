#pragma once
#include <iostream>
using namespace std;

class Population; 
class Military;

class ResourceManager {
private:
    int food;
    int wood;
    int iron;
    int stone;

public:
    ResourceManager();

    void harvestFood(int amount);
    void harvestWood(int amount);
    void harvestIron(int amount);

    void consumeFood(int amount);
    void consumeWood(int amount);
    void consumeIron(int amount);

    bool tradeFoodForWood(int foodAmount, int woodAmount);
    bool tradeWoodForIron(int woodAmount, int ironAmount);

    void handleDrought();
    void handleBumperCrop();

    int getFood() const;
    int getWood() const;
    int getIron() const;
    int getStone() const;

    void printResources() const;
};
