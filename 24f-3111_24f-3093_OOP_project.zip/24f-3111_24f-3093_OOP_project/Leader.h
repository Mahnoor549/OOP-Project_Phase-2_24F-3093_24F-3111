#pragma once
#include <iostream>
#include <string>
using namespace std;

class Military;  // Forward declaration
class Economy;   // Forward declaration

class Leader {
private:
    string name;
    string title;       
    bool isDemocratic;  
    int approvalRating; 
    int termYears;    

public:
    Leader(string leaderName, string leaderTitle, bool democratic);

    void holdElection(Economy& economy);
    void handleCoup(Military& military);
    void declareWar(Military& military, Economy& economy);

    void makePeace();
    void corruptTreasury(Economy& economy);

    string getName();
    string getTitle();
    int getApproval();
};

