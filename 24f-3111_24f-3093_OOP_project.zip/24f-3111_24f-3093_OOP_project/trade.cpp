#include "Trade.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;

// TradeOffer implementation
TradeOffer::TradeOffer(string kingdom, string reqRes, string offRes,
    int reqAmt, int offAmt, bool legal) :
    offeringKingdom(kingdom), requestedResource(reqRes), offeredResource(offRes),
    requestedAmount(reqAmt), offeredAmount(offAmt), isLegal(legal) {
    riskPercentage = calculateRisk();
}

void TradeOffer::display() const {
    cout << "\n=== TRADE OFFER ===" << endl;
    cout << "From: " << offeringKingdom << endl;
    cout << "Wants: " << requestedAmount << " " << requestedResource << endl;
    cout << "Offers: " << offeredAmount << " " << offeredResource << endl;
    cout << "Type: " << (isLegal ? "Legal" : "Black Market") << endl;
    if (!isLegal) {
        cout << "Risk: " << riskPercentage << "% chance of detection" << endl;
    }
}

float TradeOffer::calculateRisk() const {
    if (isLegal) return 0.0f;
    // Higher risk for more valuable trades
    return min(90.0f, 10.0f + (requestedAmount * offeredAmount) / 100.0f);
}

bool TradeOffer::executeTrade() {
    if (!isLegal) {
        srand(time(0));
        float roll = rand() % 100;
        if (roll < riskPercentage) {
            cout << "SMUGGLING DETECTED! Trade intercepted!" << endl;
            return false;
        }
    }
    cout << "Trade successful!" << endl;
    return true;
}

void TradeOffer::saveToFile() const {
    ofstream file(isLegal ? "legal_trades.txt" : "blackmarket_trades.txt", ios::app);
    if (file.is_open()) {
        file << offeringKingdom << "," << requestedResource << "," << requestedAmount << ","
            << offeredResource << "," << offeredAmount << "," << riskPercentage << endl;
        file.close();
    }
}

// Market implementation
Market::Market() : legalCount(0), blackMarketCount(0), priceIndex(1.0f) {
    srand(time(0));
}

void Market::postOffer() {
    if (legalCount >= MAX_OFFERS || blackMarketCount >= MAX_OFFERS) {
        cout << "Maximum offers reached!" << endl;
        return;
    }

    string kingdom, reqRes, offRes;
    int reqAmt, offAmt, type;

    cout << "\nEnter your kingdom name: ";
    getline(cin, kingdom);
    cout << "Enter resource you want: ";
    getline(cin, reqRes);
    cout << "Enter amount you want: ";
    cin >> reqAmt;
    cin.ignore();
    cout << "Enter resource you're offering: ";
    getline(cin, offRes);
    cout << "Enter amount you're offering: ";
    cin >> offAmt;
    cin.ignore();
    cout << "Offer type (1-Legal, 2-Black Market): ";
    cin >> type;
    cin.ignore();

    bool isLegal = (type == 1);
    TradeOffer* newOffer = new TradeOffer(kingdom, reqRes, offRes, reqAmt, offAmt, isLegal);

    if (isLegal) {
        legalOffers[legalCount++] = newOffer;
    }
    else {
        blackMarketOffers[blackMarketCount++] = newOffer;
    }

    newOffer->display();
    newOffer->saveToFile();
    cout << "Offer posted successfully!" << endl;
}

void Market::listOffers(bool showLegal) const {
    cout << "\n=== " << (showLegal ? "LEGAL" : "BLACK MARKET") << " OFFERS ===" << endl;
    int count = showLegal ? legalCount : blackMarketCount;
    TradeOffer* const* offers = showLegal ? legalOffers : blackMarketOffers;

    for (int i = 0; i < count; i++) {
        cout << "\nOffer #" << i + 1 << endl;
        offers[i]->display();
    }
}

void Market::acceptOffer(bool isLegal) {
    listOffers(isLegal);
    int count = isLegal ? legalCount : blackMarketCount;
    if (count == 0) return;

    int choice;
    cout << "Enter offer number to accept (0 to cancel): ";
    cin >> choice;
    cin.ignore();

    if (choice > 0 && choice <= count) {
        TradeOffer* offer = isLegal ? legalOffers[choice - 1] : blackMarketOffers[choice - 1];
        if (offer->executeTrade()) {
            adjustPrices();
        }
    }
}

void Market::adjustPrices() {
    // Simple price fluctuation simulation
    priceIndex += (rand() % 21 - 10) / 100.0f; // -10% to +10% change
    priceIndex = max(0.5f, min(2.0f, priceIndex)); // Keep between 50% and 200%
    cout << "Market prices adjusted. Current index: " << priceIndex << endl;
}

bool Market::detectSmuggling() const {
    if (blackMarketCount == 0) return false;
    return (rand() % 100) < 30; // 30% chance to detect any smuggling
}