#include "Map.h"
#include <iostream>
#include <cstdlib>
using namespace std;

// Territory implementation
Territory::Territory(string n, string o, int res, int def) :
    name(n), owner(o), resources(res), defenses(def) {
}

void Territory::display() const {
    cout << "\nTerritory: " << name << endl;
    cout << "Owner: " << owner << endl;
    cout << "Resources: " << resources << endl;
    cout << "Defenses: " << defenses << endl;
}

void Territory::changeOwner(string newOwner) {
    owner = newOwner;
    cout << name << " now belongs to " << newOwner << endl;
}

void Territory::upgradeDefenses() {
    defenses += 10;
    cout << name << " defenses upgraded to " << defenses << endl;
}

string Territory::getName() const { return name; }
string Territory::getOwner() const { return owner; }

// Movement implementation
Movement::Movement(string entity, string start, string end) :
    movingEntity(entity), startTerritory(start), endTerritory(end), progress(0) {
}

void Movement::updatePosition() {
    if (progress < 100) {
        progress += 25; // Move 25% each update
        if (progress > 100) progress = 100;
    }
}

bool Movement::isComplete() const {
    return progress >= 100;
}

void Movement::display() const {
    cout << movingEntity << " moving from " << startTerritory
        << " to " << endTerritory << " (" << progress << "%)" << endl;
}

// GameMap implementation
GameMap::GameMap() : movementCount(0) {
    initializeMap();
}

void GameMap::initializeMap() {
    // Simple 5x5 grid with basic territories
    string owners[3] = { "Player1", "Player2", "Neutral" };
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            string name = "Territory_" + to_string(i) + "_" + to_string(j);
            string owner = owners[rand() % 3];
            int res = 100 + rand() % 900;
            int def = 10 + rand() % 90;
            territories[i][j] = new Territory(name, owner, res, def);
        }
    }
}

void GameMap::display() const {
    cout << "\n=== KINGDOM MAP ===" << endl;
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            cout << "[" << territories[i][j]->getName() << ":"
                << territories[i][j]->getOwner()[0] << "] ";
        }
        cout << endl;
    }
}

void GameMap::moveArmy() {
    if (movementCount >= 10) {
        cout << "Maximum concurrent movements reached!" << endl;
        return;
    }

    string entity, start, end;
    cout << "\nEnter moving army name: ";
    getline(cin, entity);

    display();
    cout << "Enter starting territory: ";
    getline(cin, start);
    cout << "Enter destination territory: ";
    getline(cin, end);

    Territory* startTer = findTerritory(start);
    Territory* endTer = findTerritory(end);

    if (!startTer || !endTer) {
        cout << "Invalid territory names!" << endl;
        return;
    }

    movements[movementCount] = new Movement(entity, start, end);
    cout << "Movement started: ";
    movements[movementCount]->display();
    movementCount++;
}

void GameMap::updateMovements() {
    cout << "\n=== MOVEMENT UPDATES ===" << endl;
    for (int i = 0; i < movementCount; i++) {
        if (!movements[i]->isComplete()) {
            movements[i]->updatePosition();
            movements[i]->display();

            if (movements[i]->isComplete()) {
                cout << "Movement complete!" << endl;
                // Change territory ownership when army arrives
                Territory* ter = findTerritory(movements[i]->endTerritory);
                Territory* start = findTerritory(movements[i]->startTerritory);
                if (ter && start) {
                    ter->changeOwner(start->getOwner());
                }
            }
        }
    }
}

int GameMap::calculateDistance(string t1, string t2) const {
    // Simple distance calculation (manhattan distance)
    for (int i1 = 0; i1 < SIZE; i1++) {
        for (int j1 = 0; j1 < SIZE; j1++) {
            if (territories[i1][j1]->getName() == t1) {
                for (int i2 = 0; i2 < SIZE; i2++) {
                    for (int j2 = 0; j2 < SIZE; j2++) {
                        if (territories[i2][j2]->getName() == t2) {
                            return abs(i1 - i2) + abs(j1 - j2);
                        }
                    }
                }
            }
        }
    }
    return -1; // Not found
}

Territory* GameMap::findTerritory(string name) const {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (territories[i][j]->getName() == name) {
                return territories[i][j];
            }
        }
    }
    return nullptr;
}