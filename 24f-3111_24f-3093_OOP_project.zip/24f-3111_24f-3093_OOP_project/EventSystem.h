#pragma once
#include <iostream>
#include <cstdlib>  
#include <ctime>   
using namespace std;

class Population; 
class Economy;
class Military;

class EventSystem {
private:
    int eventSeverity;  

public:
    EventSystem();
    void triggerEvent(Population& pop, Economy& economy, Military& military);
    void resolveEvent(int responseChoice, Population& pop, Economy& economy);
    void applyFamine(Population& pop);
    void applyPlague(Population& pop);
    void applyWar(Economy& economy, Military& military);
};
