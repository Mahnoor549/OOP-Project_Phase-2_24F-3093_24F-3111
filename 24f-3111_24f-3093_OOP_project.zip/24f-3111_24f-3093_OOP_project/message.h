#pragma once
#ifndef MESSAGE_H
#define MESSAGE_H

#include <string>
#include <ctime>
using namespace std;

class Message {
private:
    string sender;
    string receiver;
    string content;
    string messageType;
    string timestamp;
public:
    Message(string s, string r, string c, string t);
    void display();
    void saveToFile();
};

class CommunicationCenter {
private:
    Message* messages[100];
    int messageCount;
public:
    CommunicationCenter();
    void sendMessage();
    void viewMessageHistory();
};

#endif
