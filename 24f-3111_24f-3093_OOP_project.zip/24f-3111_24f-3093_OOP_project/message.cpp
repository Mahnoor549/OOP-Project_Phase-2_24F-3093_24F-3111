#include "Message.h"
#include <iostream>
#include <fstream>
using namespace std;

Message::Message(string s, string r, string c, string t) {
    sender = s;
    receiver = r;
    content = c;
    messageType = t;

    // Get current time safely
    time_t now = time(0);
    char timeStr[26];
    ctime_s(timeStr, sizeof(timeStr), &now);
    timestamp = timeStr;
}

void Message::display() {
    cout << "-------------------------" << endl;
    cout << "From: " << sender << endl;
    cout << "To: " << receiver << endl;
    cout << "Type: " << messageType << endl;
    cout << "Time: " << timestamp;
    cout << "Message: " << content << endl;
    cout << "-------------------------" << endl;
}

void Message::saveToFile() {
    ofstream file("messages.txt", ios::app);
    if (file.is_open()) {
        file << timestamp << "," << sender << "," << receiver << "," << messageType << "," << content << endl;
        file.close();
    }
    else {
        cout << "Unable to save message to file!" << endl;
    }
}

CommunicationCenter::CommunicationCenter() : messageCount(0) {}

void CommunicationCenter::sendMessage() {
    string sender, receiver, content, type;

    cout << "Enter your name (sender): ";
    getline(cin, sender);

    cout << "Enter recipient name: ";
    getline(cin, receiver);

    cout << "Enter message type (ALLIANCE/TRADE/THREAT/NORMAL): ";
    getline(cin, type);

    cout << "Enter your message: ";
    getline(cin, content);

    messages[messageCount] = new Message(sender, receiver, content, type);
    messages[messageCount]->display();
    messages[messageCount]->saveToFile();
    messageCount++;

    cout << "Message sent successfully!" << endl;
}

void CommunicationCenter::viewMessageHistory() {
    cout << "=== MESSAGE HISTORY ===" << endl;
    for (int i = 0; i < messageCount; i++) {
        messages[i]->display();
    }
}