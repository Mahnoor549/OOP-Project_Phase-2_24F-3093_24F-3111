#include "Treaties.h"
#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

// Base Treaty implementation
Treaty::Treaty(string k1, string k2, int dur) :
    kingdom1(k1), kingdom2(k2), duration(dur), active(true) {
    startDate = time(0);
}

bool Treaty::isActive() const {
    return active && (difftime(time(0), startDate) < duration * 86400);
}

void Treaty::breakTreaty() {
    active = false;
    cout << "Treaty between " << kingdom1 << " and " << kingdom2 << " has been broken!" << endl;
    cout << "Both kingdoms suffer reputation loss!" << endl;
}

void Treaty::display() const {
    cout << "Parties: " << kingdom1 << " <-> " << kingdom2 << endl;
    cout << "Status: " << (active ? "Active" : "Broken") << endl;
    cout << "Terms: " << getTerms() << endl;
}

void Treaty::saveToFile() const {
    ofstream file("treaties.txt", ios::app);
    if (file.is_open()) {
        file << kingdom1 << "," << kingdom2 << ","
            << (active ? "Active" : "Broken") << ","
            << getTerms() << endl;
        file.close();
    }
}

// AllianceTreaty implementation
AllianceTreaty::AllianceTreaty(string k1, string k2, int dur) :
    Treaty(k1, k2, dur) {
}

string AllianceTreaty::getTerms() const {
    return "Mutual defense pact: Attack on one is attack on both";
}

// TradeTreaty implementation
TradeTreaty::TradeTreaty(string k1, string k2, int dur, int bonus) :
    Treaty(k1, k2, dur), tradeBonus(bonus) {
}

string TradeTreaty::getTerms() const {
    return "Trade bonus: " + to_string(tradeBonus) + "% better prices";
}

// DiplomacyManager implementation
DiplomacyManager::DiplomacyManager() : treatyCount(0) {}

void DiplomacyManager::proposeTreaty() {
    if (treatyCount >= MAX_TREATIES) {
        cout << "Maximum treaties reached!" << endl;
        return;
    }

    string k1, k2;
    int type, dur, bonus;

    cout << "Enter first kingdom: ";
    getline(cin, k1);
    cout << "Enter second kingdom: ";
    getline(cin, k2);
    cout << "Enter duration (days): ";
    cin >> dur;
    cin.ignore();

    cout << "Treaty type:\n1. Alliance\n2. Trade Agreement\nChoose: ";
    cin >> type;
    cin.ignore();

    if (type == 1) {
        treaties[treatyCount++] = new AllianceTreaty(k1, k2, dur);
    }
    else if (type == 2) {
        cout << "Enter trade bonus %: ";
        cin >> bonus;
        cin.ignore();
        treaties[treatyCount++] = new TradeTreaty(k1, k2, dur, bonus);
    }

    treaties[treatyCount - 1]->display();
    treaties[treatyCount - 1]->saveToFile();
    cout << "Treaty created successfully!" << endl;
}

void DiplomacyManager::listActiveTreaties() const {
    cout << "=== ACTIVE TREATIES ===" << endl;
    for (int i = 0; i < treatyCount; i++) {
        if (treaties[i]->isActive()) {
            treaties[i]->display();
            cout << "---------------------" << endl;
        }
    }
}

void DiplomacyManager::breakTreaty() {
    listActiveTreaties();
    if (treatyCount == 0) return;

    int choice;
    cout << "Enter treaty number to break (0 to cancel): ";
    cin >> choice;
    cin.ignore();

    if (choice > 0 && choice <= treatyCount) {
        treaties[choice - 1]->breakTreaty();
        treaties[choice - 1]->saveToFile();
    }
}