#pragma once
#include <iostream>
using namespace std;

class Economy;  

class Bank {
private:
    int totalGold;         
    float interestRate;    
    int corruptionLevel;   

public:
    Bank(Economy eco);
    bool grantLoan(Economy& economy, int amount);
    void detectFraud(Economy& economy);
    void adjustInterestRates(int inflation);
    void triggerBankRun(Economy& economy);
    int getGoldReserves();
    float getInterestRate();
};

