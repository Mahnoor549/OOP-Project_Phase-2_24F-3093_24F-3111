#pragma once
#include "social.h"

class Noble : public SocialClass {
public:
    Noble();
    void payTax() override;
    void demandRights() override;
};