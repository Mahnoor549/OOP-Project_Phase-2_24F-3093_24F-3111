#pragma once
#include <iostream>
using namespace std;

class Population {
private:
    int totalPeople;    
    int happiness;     
    int foodSupply;     

public:
    Population(); 

    void updatePopulation(int h);
    void calculateHappiness(int h);
    bool triggerRevolt();

    int getPopulation();
    int getHappiness();

    void setFoodSupply(int food);
};
