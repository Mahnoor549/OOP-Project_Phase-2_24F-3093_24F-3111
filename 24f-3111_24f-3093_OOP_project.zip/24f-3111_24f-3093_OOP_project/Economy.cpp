#include "Economy.h"

Economy::Economy() : treasury(5000), inflation(1.0), militaryBudget(0), foodBudget(0) {}


void Economy::collectTaxes(SocialClass* classes[], int classCount) {
    if (classCount <= 0) {
        cout << "Warning: No social classes to collect taxes from!" << endl;
        return;
    }
    for (int i = 0; i < classCount; i++) {
        classes[i]->payTax();
        treasury += classes[i]->getInfluence() * 10;  
    }
    cout << "Taxes collected! Treasury: " << treasury << endl;
}

void Economy::adjustInflation(int totalSpending) {
    if (totalSpending > treasury / 2) {
        inflation *= 1.1;
        cout << "Inflation rises to " << (inflation - 1) * 100 << "%" << endl;
    }
}

void Economy::allocateBudget(int military, int food) {
    militaryBudget = military;
    foodBudget = food;
    treasury -= (military + food);
    cout << "Budget allocated - Military: " << military
        << ", Food: " << food << endl;
}

int Economy::getTreasury() { return treasury; }
float Economy::getInflation() { return inflation; }
