#pragma once
#include <iostream>
using namespace std;

class Population;  // Forward declaration

class Military {
private:
    int soldierCount;    
    int morale;       
    int trainingLevel;    
    int weapons;         

public:
    Military();
    int armyStrength=0;
    void recruitSoldiers(Population& population, int recruits);
    void trainArmy(int days);
    void checkMorale(int foodSupply, int goldPayment);
    bool fightBattle(int enemyStrength); 

    int getSoldierCount();
    int getArmyStrength();
    int getMorale();

    void setWeapons(int count);
};