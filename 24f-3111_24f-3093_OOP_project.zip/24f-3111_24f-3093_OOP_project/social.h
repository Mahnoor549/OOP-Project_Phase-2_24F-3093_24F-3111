#pragma once
#include <iostream>
using namespace std;

class SocialClass {
protected:
    string className;
    int taxRate;
    int influence;
    int happiness;

public:
    SocialClass(string name, int tax, int influence);
    virtual ~SocialClass() = default;

    virtual void payTax() = 0;       
    virtual void demandRights();  
    virtual int getInfluence();   

    string getClassName();
    int getHappiness();
};
