#include "Kingdom.h"
#include <iostream>
using namespace std;
#include <cstdlib> // For rand()

Kingdom::Kingdom(): bank(economy),leader("King Arthur", "King", false),
dayCount(0) {
    gold = 1000;    // Starting gold
    food = 500;     // Starting food
    populations = 200; // Starting people
    isGameOver = false;
}
void Kingdom::runSimulation() {
    while (true) {
        cout << endl<<"=== Day " << dayCount << " ===" << endl;
        displayStatus();
        showMenu();

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 0) break;
        handleChoice(choice);
        updateGameState();
        dayCount++;
    }
}

void Kingdom::showMenu() {
    cout << endl << "Kingdom Management Menu:"<< endl ;
    cout << "1. Collect Taxes"<< endl;
    cout << "2. Recruit Soldiers" << endl;
    cout << "3. Train Army" << endl;
    cout << "4. Fight Army" << endl;
    cout << "5. Request Bank Loan" << endl;
    cout << "6. Manage Resources" << endl;
    cout << "7. Handle Social Issues" << endl;
    cout << "8. Pass Day" << endl;
    cout << "9.Random Event Generate" << endl;
    cout << "0. Exit Game" << endl;
}

void Kingdom::handleChoice(int choice) {
    switch (choice) {
    case 1: {
        // Create social classes array without vector
        const int classCount = 3;
        SocialClass* classes[classCount] = {
            new Peasant(),
            new Merchant(),
            new Noble()
        };

        economy.collectTaxes(classes, classCount);

        // Clean up memory
        for (int i = 0; i < classCount; i++) {
            delete classes[i];
        }
        break;
    }
    case 2:
        military.recruitSoldiers(population, 10);
        break;
    case 3:
        military.trainArmy(3);
        break;
    case 4:
        military.fightBattle(military.armyStrength);
        break;
    case 5:
        bank.grantLoan(economy,500);
        break;
    case 6:
        resources.harvestFood(100);
        resources.harvestWood(50);
        break;
    case 7:
        leader.holdElection(economy);
        break;
    case 8:
        break;
    case 9:
        handleRandomEvents();
        break;
    default:
        cout << "Invalid choice!\n";
    }

}
void Kingdom::updateGameState() {
    population.updatePopulation(10);
    military.checkMorale(resources.getFood(), economy.getTreasury());
    if (rand() % 5 == 0) {  
        events.triggerEvent(population, economy, military);
    }
    if (population.getPopulation() <= 0 || economy.getTreasury() <= -1000) {
        cout << "GAME OVER! Your kingdom has fallen.";
        exit(0);
    }
}

void Kingdom::displayStatus() {
    cout << "Kingdom Status:";
    cout << " Population: " << population.getPopulation();
    cout << " Treasury: " << economy.getTreasury() << " gold";
    cout << " Army: " << military.getSoldierCount() << " soldiers";
    cout << " Food: " << resources.getFood() << " units";
    cout << " Leader: " << leader.getName() << " (" << leader.getApproval() << "% approval)";
}
void Kingdom::handleRandomEvents() {
    int eventChance = rand() % 10;

    if (eventChance < 3) { 
        int eventType = rand() % 3;

        switch (eventType) {
        case 0: // Famine
            food -= 100;
            cout << "DISASTER! Famine strikes! (-100 food)" << endl;
            break;
        case 1: // War
            gold -= 200;
            populations -= 20;
            cout << "DISASTER! War breaks out! (-200 gold, -20 people)" << endl;
            break;
        case 2: // Plague
            populations -= 50;
            cout << "DISASTER! Plague spreads! (-50 people)" << endl;
            break;
        }
    }
    else {
        cout << "Today was peaceful." << endl;
    }
}
bool Kingdom::checkGameOver() {
    if (gold <= 0) {
        cout << "You went bankrupt!" << endl;
        return true;
    }
    if (populations <= 0) {
        cout << "Everyone died!" << endl;
        return true;
    }
    if (food <= 0) {
        cout << "Starved to death!" << endl;
        return true;
    }
    return false; // Game continues
}